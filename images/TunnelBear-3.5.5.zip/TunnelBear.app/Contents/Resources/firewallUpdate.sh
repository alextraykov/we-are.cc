#!/bin/bash

# @param String message - The message to log
readonly LOG_MESSAGE_COMMAND=$(basename "${0}")
logMessage()
{
	echo "$(date '+%a %b %e %T %Y') $LOG_MESSAGE_COMMAND: "${@} >> "${SCRIPT_LOG_FILE}"
}

updateFirewallRules()
{
	logMessage "Updating firewall rules"

	existing=$(cat /etc/pf.conf)
	
	# enable pf
	pfctl -e

	# scrub must be at the top
	# anchors must be at the bottom
	read -d '' rules <<- EOF
		scrub in all

		${existing}

		anchor "com.tunnelbear" {
			${RULES}
		}
	EOF

	echo -e "$rules\n" | pfctl -f -
}

teardown()
{
	logMessage "Tearing down firewall"
	# flush our anchor
	pfctl -a 'com.tunnelbear' -F all
	# flush all rulesets
	pfctl -F all
	# load defaults
	pfctl -f /etc/pf.conf
}

status()
{
	pfctl -s rules
	pfctl -a "com.tunnelbear" -s rules
}

get_default_interface()
{
  # routes are in priority order so take the one at the top that's not a tunnel
  # except when ipsec is enabled. Priority is lost, but is restored when ipsec interface
  # is disabled
  netstat -nrf inet | grep default | grep -v ipsec | grep -v utun | awk '{ print $NF }' | head -1
}

################# START HERE ####################

readonly SCRIPT_LOG_FILE="/var/log/tbeard/vigilant.log"

if [ "$1" == "teardown" ]; then
	teardown
elif [ "$1" == "status" ]; then
	status
elif [ "$1" == "getDefaultInterface" ]; then
	get_default_interface
else
	RULES="$1"
	updateFirewallRules
fi
