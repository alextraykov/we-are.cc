#! /bin/sh

reload_helper()
{
  launchctl kickstart -k system/com.tunnelbear.mac.tbeard
}

update_status()
{
	launchctl list | grep tbeard
}

################# START HERE ####################

OPERATION="$1"

if [ "$OPERATION" == "reload" ]; then
  reload_helper
elif [ "$OPERATION" == "status" ]; then
  update_status
fi
