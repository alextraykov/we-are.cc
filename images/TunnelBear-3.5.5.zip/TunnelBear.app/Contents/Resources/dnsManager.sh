#! /bin/sh

# @param String message - The message to log
readonly LOG_COMMAND=$(basename "${0}")
readonly LOG_FILE="/var/log/tbeard/dnsManager.log"

readonly STATE_PATTERN="State:/"
readonly SETUP_PATTERN="Setup:/"

readonly BACKUP_STATE_PATTERN="com.tunnelbear:/Backup/State/"
readonly BACKUP_SETUP_PATTERN="com.tunnelbear:/Backup/Setup/"

readonly VPN_DNS_KEY="com.tunnelbear:/DNS"

function log
{
echo "$(date '+%a %b %e %T %Y') $LOG_COMMAND: "${@} >> "${LOG_FILE}"
}

function logNewLine
{
echo "\n" >> "${LOG_FILE}"
}


###### CONFIG LOCATIONS ######
# com.tunnelbear:/DNS

###### BACKUP LOCATIONS ######
# Setup backups that were modified to get VPN to work
# com.tunnelbear:/Backup/Setup/{backup_key}
# -----
# State backups that were modfied to get VPN to work
# com.tunnelbear:/Backup/State/{backup_key}

function copy_dictionary_for_keys
{
	local from_key=$1
	local to_key=$2

	log "copy_dictionary_for_keys: $from_key -> $to_key" 

	# Empty keys aren't supported
	[[ -z $from_key ]] && return 0
	[[ -z $to_key ]] && return 0

	log "keys are valid to copy"

	scutil <<- EOF
		open
		d.init
		get $from_key
		set $to_key
		quit
	EOF
}

function delete_key
{	
	local key=$1

	log "delete_key $key" 

	# Empty keys aren't supported
	[[ -z $key ]] && return 0

	log "key is valid to delete"

	scutil <<- EOF
		open
		remove $key
		quit
	EOF
}

function backup_key_for_key
{
	local key=$1

	# Empty keys aren't supported
	[[ -z $key ]] && return 0

	# We do not backup TunnelBear Keys
	[[ $key == *"Backup"* ]] && return 0

	# Substitute 
	key=${key/$STATE_PATTERN/$BACKUP_STATE_PATTERN}
	key=${key/$SETUP_PATTERN/$BACKUP_SETUP_PATTERN}

	echo $key
}

function original_key_for_backup_key
{
	local key=$1

	# Empty keys aren't supported
	[[ -z $key ]] && return 0

	# We need a Backup in the key
	[[ ! $key == *"Backup"* ]] && return 0

	# Substitute 
	key=${key/$BACKUP_STATE_PATTERN/$STATE_PATTERN}
	key=${key/$BACKUP_SETUP_PATTERN/$SETUP_PATTERN}

	echo $key
}

function setup_key_for_state_key
{
	local key=$1

	# Empty keys aren't supported
	[[ -z $key ]] && return 0

	# Substitute 
	key=${key/$STATE_PATTERN/$SETUP_PATTERN}

	echo $key
}

function get_existing_keys_for_key_pattern
{
	local key_pattern=$1
	local scutil_output

	# Empty keys aren't supported
	[[ -z $key_pattern ]] && return 0

	scutil_output=`/usr/sbin/scutil <<-EOF
		open
		list $key_pattern
		quit
	EOF`

	# Don't return the no keys statement
	[[ "$scutil_output" =~ "no keys" ]] && return 0

	# Remove the subKey text
	echo $scutil_output | sed -E 's/subKey \[[0-9]+\] = //g'
}

function get_key_content
{
	local key=$1

	# Empty keys aren't supported
	[[ -z $key ]] && return 0

	local existing_key=`get_existing_keys_for_key_pattern $key`

	# Key doesn't exist
	[[ -z $existing_key ]] && return 0

	local scutil_output=`/usr/sbin/scutil <<-EOF
		open
		show $existing_key
		quit
	EOF`

	# Don't return the no keys statement
	[[ "$scutil_output" =~ "No such key" ]] && return 0

	echo $scutil_output
}

function get_key_is_vpn_managed
{
	local key=$1
	# Empty keys aren't supported
	[[ -z $key ]] && return 0

	# Get get key content and extract the value for IsVPNManaged
	local is_vpn_managed=`get_key_content "$key" | grep "IsVPNManaged" | sed -E 's/.*IsVPNManaged : ([A-z]+).*/\1/'`
	log "$key's is_vpn_managed: $is_vpn_managed"
	echo $is_vpn_managed
}

function get_all_dns_state_keys
{
	# We usually only want to manipulate setup keys, but in order for
	# us to know which setup keys we use the state keys as they're pretty
	# much guaranteed to be there.
	get_existing_keys_for_key_pattern "State:/Network/Global/DNS"
	get_existing_keys_for_key_pattern "State:/Network/Service/[^/]+/DNS"
}

function get_all_dns_setup_keys
{
	get_existing_keys_for_key_pattern "Setup:/Network/Global/DNS"
	get_existing_keys_for_key_pattern "Setup:/Network/Service/[^/]+/DNS"
}

function get_all_vpn_keys
{
	get_existing_keys_for_key_pattern "com.tunnelbear:/.*"
}

function get_all_backup_keys
{
	get_existing_keys_for_key_pattern "com.tunnelbear:/Backup/.*"
}

##### ACTIONS

function backup_all_keys
{
	log "backup_all_keys"

	local keys=(`get_all_dns_state_keys`)

	for key in "${keys[@]}"
	do
		# Only ever backup setup keys.
		local setup_key=`setup_key_for_state_key $key`
		log "Backing up key: $setup_key"
		local key_content=`get_key_content $setup_key`
		local is_key_vpn_managed=`get_key_is_vpn_managed $setup_key`
		local backup_key=`backup_key_for_key $setup_key`
		local existing_backup_content=`get_key_content $backup_key`

		if [[ "$is_key_vpn_managed" == "true" ]]; then
			log "Warning -- Not backing up key, it's the VPN DNS.."
		elif [[ "$key_content" == "$existing_backup_content" ]]; then
			log "Not backing up key, it's already backed up"
		else
			copy_dictionary_for_keys $setup_key $backup_key
		fi
	done
}

function restore_all_backups
{
	log "restore_all_backups"

	# Loop through all keys that aren't backed up
	local backup_keys=(`get_all_backup_keys`)
	for backup_key in "${backup_keys[@]}"
	do
		# The original place to restore it to
		local original_key=`original_key_for_backup_key $backup_key`
		copy_dictionary_for_keys $backup_key $original_key
	done
}

function remove_old_vpn_keys
{
	log "remove_old_vpn_keys"

	# Loop through all keys that are associated with VPN
	local all_dns_setup_keys=(`get_all_dns_setup_keys`)
	for dns_key in "${all_dns_setup_keys[@]}"
	do
		local is_key_vpn_managed=`get_key_is_vpn_managed $dns_key`
		if [[ "$is_key_vpn_managed" == "true" ]]; then
			log "Old key found"
			delete_key $dns_key
		fi
	done
}

function remove_vpn_config_keys
{
	log "remove_vpn_config_keys"
	# Loop through all keys that are associated with VPN
	local vpn_keys=(`get_all_vpn_keys`)
	for vpn_key in "${vpn_keys[@]}"
	do
		delete_key $vpn_key
	done
}

function apply_vpn_dns
{
	log "apply_vpn_dns"
	local vpn_dns_key=`get_existing_keys_for_key_pattern "$VPN_DNS_KEY"`

	# VPN DNS not set
	[[ -z $vpn_dns_key ]] && return 0

	log "looping through all dns keys"

	local state_keys=(`get_all_dns_state_keys`)
	for state_key in "${state_keys[@]}"
	do

		# We do not want to change state of network interfaces, it messes up the connection
		# and although it looks like the dns is correct when looking at scutil --dns you can't
		# actually do DNS lookups
		#
		# So instead we apply it to the setup variant
		local setup_key=`setup_key_for_state_key $state_key`
		copy_dictionary_for_keys $vpn_dns_key $setup_key
	done
}

################# START HERE ####################

OPERATION="$1"

log "================================="
log "Running operation: $OPERATION"

if [ "$OPERATION" == "backup" ]; then
	backup_all_keys	
elif [ "$OPERATION" == "restore" ]; then
	restore_all_backups
	remove_old_vpn_keys
	remove_vpn_config_keys
elif [ "$OPERATION" == "apply_vpn" ]; then
	backup_all_keys
	apply_vpn_dns
elif [ "$OPERATION" == "remove_old" ]; then
	remove_old_vpn_keys
	remove_vpn_config_keys
fi
